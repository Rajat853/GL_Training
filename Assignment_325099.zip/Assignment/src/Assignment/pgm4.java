package Assignment;

public class pgm4 {

	int pid;
	String pName;
	int pRate;
	int uPurchase;
	int price;
	String grade;
	
	
	public void cal() {
		price=pRate*uPurchase;
	}
	
	public void gradeMethod() {
		if(price<25000)
			grade="GradeA";
		else
			grade="GradeB";
	}
	
}
