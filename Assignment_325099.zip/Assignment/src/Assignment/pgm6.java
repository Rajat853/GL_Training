package Assignment;
import java.util.*;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<pgm4> p = new ArrayList<pgm4>();
	
		pgm5 p5=new pgm5();
		p=p5.read_excel();
		p5.write_excel(p);
		
	}

}
