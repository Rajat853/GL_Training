package Assignment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm5 {

	public ArrayList<pgm4> al=new ArrayList<pgm4>();
	
	public ArrayList<pgm4> read_excel(){
	
		try {
		File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Assignment1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		for(int i=1;i<=3;i++) {
			pgm4 p=new pgm4();
		
			XSSFRow r=sh.getRow(i);
			
			XSSFCell c=r.getCell(0);
			p.pid=(int)c.getNumericCellValue();
		
			XSSFCell c1=r.getCell(1);
			p.pName=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(2);
			p.pRate=(int)c2.getNumericCellValue();
			
			XSSFCell c3=r.getCell(3);
			p.uPurchase=(int)c3.getNumericCellValue();
			
			p.cal();
			p.gradeMethod();
			
			al.add(p);
			
		}
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return al;	
	}
	
	
	public void write_excel(ArrayList<pgm4> ap) {
		
		try {
			File f=new File("C:\\Users\\rajat.kumar2\\Desktop\\Excel File\\Assignment1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			int row=1;
			
			for(pgm4 in:ap) {
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(4);
				c.setCellValue(in.price);
				XSSFCell c1=r.createCell(5);
				c1.setCellValue(in.grade);
				row++;	
			}
			
			FileOutputStream  fos=new FileOutputStream(f);
			wb.write(fos);
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	
}
	
}
