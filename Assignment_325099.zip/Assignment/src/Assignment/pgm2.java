package Assignment;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[]=new int[15];
		int i=1,count=0;
		
		while(count<15)
		{
			int n=i;
			int ex=i;
			int sum=0;
			int length=0;
			
			while(ex>0) {
				ex/=10;
				length++;
			}
			
			while(n>0) {
				int d=n%10;
				sum+=Math.pow(d,length);
				n/=10;
			}
			
			if(sum==i)
				arr[count++]=i;
			
				i++;
		}
		
		for(int j=0;j<arr.length;j++)
			System.out.print(arr[j]+" ");
	}

}
