package Assignment;

public class Birds {

	public void eat() {
		
	}
	
	public void found() {
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		parrot p=new parrot();
		p.eat();
		p.found();
		p.speak("Rahul mimc");
		
		parrot p1=new parrot();
		p1.eat();
		p1.found();
		p1.speak("Prince mimc");
		
		parrot p2=new parrot();
		p2.eat();
		p2.found();
		p2.speak("Shubham mimc");
		
		owl o=new owl();
		o.eat();
		o.found();
		o.eye("nocturnal prey capture speed is high");
		owl o1=new owl();
		o1.eat();
		o1.found();
		o1.eye("nocturnal prey capture speed is slow");
		owl o2=new owl();
		o2.eat();
		o2.found();
		o2.eye("nocturnal prey capture speed is high");
		
		
		
	}

}
