package Assignment;
import java.util.*;

public class pgm7 {

	
	
	public static ArrayList<String> get_each_word(String str) {
		
		ArrayList<String> als=new ArrayList<String>();
		String s="";
		
		for(int i=0;i<str.length();i++) {
			
			if(str.charAt(i)==' ')
				{
				als.add(s);
				s="";
				}
			else
				s=s+str.charAt(i);
		}
		return als;
		
	}
	
	
	public static ArrayList<String> count_vowels(ArrayList<String> s){
		ArrayList<String> al=new ArrayList<String>();
		
		for(String st:s) {
			int count=0;
		for(int i=0;i<st.length();i++) {
			
			if(st.charAt(i)=='a' || st.charAt(i)=='e' || st.charAt(i)=='i' || st.charAt(i)=='o' || st.charAt(i)=='u')
				count++;
	
			if(count>3) {
				al.add(st);
				break;
			}
				
		}	
		}
		return al;
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String st="I have learnt, oops concepts, inheritance, exception handling, arraylist and string handling";
		ArrayList<String> al=new ArrayList<String>();
		
		al=count_vowels(get_each_word(st));
		
		for(String str:al)
			System.out.print(str);
		
	}

}
