package Assignment;

public class Student {
	
	int rollno;
	String name;
	int java;
	int sel;
	int avg;
	
	Student(int rollno,String name,int java,int sel){
		
		this.rollno=rollno;
		this.name=name;
	    this.java=java;
	    this.sel=sel;
	}
	
	
	public void average() {
		avg=(sel+java)/2;
	}
	
	public void display() {
		System.out.println("Rollno : "+rollno+" Name : "+name
				           +" Java : "+java +" Selenium : "+sel);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1=new Student(1,"Rajat",90,99);

		s1.average();
		if(s1.avg>65)
			s1.display();
		
		Student s2=new Student(2,"Shubham",96,95);
		s2.average();
		if(s2.avg>65)
			s2.display();
		
		
		Student s3=new Student(3,"Ravi",45,65);
		s3.average();
		if(s3.avg>65)
			s3.display();
	}

}
