package Assignment;
import java.util.*;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> al=new ArrayList<Integer>();
		

		for(int i=10;i<=30;i++) {
			if(i%2==0)
				al.add(i);
		}
		
		for(Integer in:al)
			System.out.print(in+" ");
	}

}
