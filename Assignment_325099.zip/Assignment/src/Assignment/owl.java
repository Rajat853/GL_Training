package Assignment;

public class owl extends Birds{

	String eyesight;
public void eat() {
			System.out.println("They eat squirrels and inscets");
	}

public void found() {
	
System.out.println("They found in all region of earth except polar ice caps and remote islands");
}

public void eye(String eyesight) {
	this.eyesight=eyesight;
}


}

