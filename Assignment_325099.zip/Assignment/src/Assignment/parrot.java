package Assignment;


public class parrot extends Birds{

	String imitate;
	
	public void eat() {
		System.out.println("They eat fruits,flowers,buds,nuts,seeds and insects");
	}
	
	public void found() {
		System.out.println("Found in warm climate all over the world");
	}
	
	public void speak(String imitate) {
		this.imitate=imitate;
	}
}
