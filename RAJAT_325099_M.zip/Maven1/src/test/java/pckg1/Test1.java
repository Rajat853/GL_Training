package pckg1;

import org.testng.annotations.Test;

public class Test1 {
  @Test
  public void f() {
	  System.out.println("Maven world");
  }
}
