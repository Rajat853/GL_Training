package Test_Runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF",
                 tags="@ROUND2",
                 plugin="html:Reports/cucumber-report")

public class testrunner extends AbstractTestNGCucumberTests{

	
}
