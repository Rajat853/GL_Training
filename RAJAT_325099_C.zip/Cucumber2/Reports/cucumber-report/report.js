$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@ROUND2"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User enters login details",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test1.login_page_is_displayed()"
});
formatter.result({
  "duration": 7963167000,
  "status": "passed"
});
formatter.match({
  "location": "test1.user_enters_login_details()"
});
formatter.result({
  "duration": 40002797800,
  "status": "passed"
});
formatter.match({
  "location": "test1.home_page_is_displayed()"
});
formatter.result({
  "duration": 146636000,
  "error_message": "org.openqa.selenium.NoSuchElementException: Cannot locate an element using xpath\u003d//div[@class\u003d\u0027header-links\u0027]//child::ul/li[1]/a\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:25:53\u0027\nSystem info: host: \u0027DEL1-LHP-N67792\u0027, ip: \u0027172.16.29.231\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: driver.version: RemoteWebDriver\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:327)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\r\n\tat STEP_DEF.test1.home_page_is_displayed(test1.java:40)\r\n\tat ✽.Then Home page is displayed(a.feature:7)\r\n",
  "status": "failed"
});
});