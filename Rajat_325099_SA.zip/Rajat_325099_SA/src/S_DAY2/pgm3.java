package S_DAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		String title=dr.getTitle();
		System.out.println("Title : "+title);
		
        
		dr.findElement(By.name("email")).sendKeys("rajatverma853@gmail.com");
     	dr.findElement(By.name("pass")).sendKeys("programming853");
     	dr.findElement(By.id("loginbutton")).click();
     	
     	
     	String s= dr.findElement(By.className("_1vp5")).getText();
	
		if(s.equals("Rajat"))
 			System.out.println("Login successfull");
 		else
 			System.out.println("Login not successfull");
		
	}

}
