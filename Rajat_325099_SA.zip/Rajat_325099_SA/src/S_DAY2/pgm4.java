package S_DAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.facebook.com");
		String title=dr.getTitle();
		System.out.println("Title : "+title);

		
		WebElement we1= dr.findElement(By.id("day"));
		Select s1=new Select(we1);
		
		s1.selectByVisibleText("11");
		
		WebElement we2= dr.findElement(By.id("month"));
		Select s2=new Select(we2);
		s2.selectByVisibleText("May");
		
		WebElement we3=dr.findElement(By.id("year"));
		Select s3=new Select(we3);
		s3.selectByVisibleText("1996");
	}

}
