package S_DAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		WebDriver dr= new ChromeDriver();
		String s="https://www.w3schools.com/html/html_tables.asp";
		
		dr.get(s);
		int r=2,c1=1;
		
		for(int i=r;i<5;i++) {
			String st=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+ i +"]/td["+ c1++ +"]")).getText();
			String st2= dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+ i +"]/td["+ c1++ +"]")).getText();
			String st3= dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr["+ i +"]/td["+ c1 +"]")).getText();
			
			c1=1;
			System.out.println(st+ " , "+st2+" , "+st3);

		}
	}

}
