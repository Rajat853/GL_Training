package S_DAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class basicLogin extends excelFile{

	WebDriver dr;
	
	public void launchchrome(String data) {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get(data);
	}
	
	public void click_btn(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	
	public void clk_rb(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}

	public void enter_txt(String xp,String data) {
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public void Verify(String xp,String data,int n) {
		String ar=dr.findElement(By.xpath(xp)).getText();
		
		if(ar.equals(data))
			excelFile.write("Pass",n);
		else
			excelFile.write("Fail",n);

	}
	
	public void closebrowser() {
		dr.close();
	}
	
	
	
	
}
