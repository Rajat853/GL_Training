package S_DAY7;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginRegister extends excelFile {
  
	basicLogin bl;
	static int count=0;
	@BeforeClass
	public void BC() {
		bl=new basicLogin();
	}
	
	
	@Test(dataProvider="data")
  public void f(String key,String xp,String data) {
  
		//System.out.println("Key =  "+key+ "  XP = " +xp + "  Data =  "+data);
		count++;
		switch(key) {
		
		case "launchchrome":
		bl.launchchrome(data);
		break;
		
		case "click_btn":
			bl.click_btn(xp);
			break;
			
		case "clk_rb":
			bl.clk_rb(xp);
			break;
			
		case "enter_txt":
			bl.enter_txt(xp, data);
			break;
			
		case "Verify":
			bl.Verify(xp, data,count);
			break;
			
		case "closebrowser":
			bl.closebrowser();
			
		}
	}
	
	
	
	@DataProvider(name="data")
	public String[][] method(){
			get_test_data();	
		return testdata;
	}
	
}
