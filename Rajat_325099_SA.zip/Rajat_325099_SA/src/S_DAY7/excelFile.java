package S_DAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelFile {

	public static String testdata[][];
	
	//public static String fileName="KeyDataDriven1.xlsx";
	public static int rowno;
	
	public static void get_test_data() {
		
		testdata=new String[18][3];
		
		for(rowno=1;rowno<19;rowno++)
		try {
			//System.out.println(rowno);
			
			File f=new File("KWDFW.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(rowno);
			
			XSSFCell cl=r.getCell(3);
			testdata[rowno-1][0]=cl.getStringCellValue();
			//System.out.println(testdata[rowno-1][0]);

			
			XSSFCell cl1=r.getCell(4);
			testdata[rowno-1][1]=cl1.getStringCellValue();			
			//System.out.println(testdata[rowno-1][1]);
			
			
			XSSFCell cl2=r.getCell(5);
			testdata[rowno-1][2]=cl2.getStringCellValue();			
			//System.out.println(testdata[rowno-1][2]);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	
	public static void write(String s,int n) {
		
		try {
			File f=new File("KWDFW.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(n);
			XSSFCell c=r.createCell(6);
			
			c.setCellValue(s);			
		
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
