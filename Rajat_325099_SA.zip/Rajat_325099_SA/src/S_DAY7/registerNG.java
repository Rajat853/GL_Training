package S_DAY7;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Assignment2.methodClass;

public class registerNG extends excelDDFW {

	methodClass mc;
	  String ar,er;
	
	@BeforeClass
	public void BC() {
		mc=new methodClass();	
     
		for(rowno=1;rowno<3;rowno++)
			get_test_data();
	
	}
	

	  @Test(dataProvider="security")
public void test1(String s1,String s2,String s3,String s4,String s5){
	  
		  er=s3;
		  ar = mc.register(s1, s2, s3, s4, s5);  
		  
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ar, er);
	  System.out.println("Actual Result :  "+ar+ ", Expected Result :  "+er );
	  sa.assertAll();
}


@DataProvider(name="security")
public String[][] provide_data() {  

	return testdata;
}
	
	
}
