package S_DAY7;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelDDFW {

public static String testdata[][];
	
	//public static String fileName="KeyDataDriven1.xlsx";
	public static int rowno;
	
	public static void get_test_data() {
		
		testdata=new String[2][5];
		try {
			//System.out.println(rowno);
			
			File f=new File("RegisterDDFW.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(rowno);
			
			XSSFCell cl=r.getCell(0);
			testdata[rowno-1][0]=cl.getStringCellValue();
			//System.out.println(testdata[rowno-1][0]);

			
			XSSFCell cl1=r.getCell(1);
			testdata[rowno-1][1]=cl1.getStringCellValue();			
			//System.out.println(testdata[rowno-1][1]);
			
			
			XSSFCell cl2=r.getCell(2);
			testdata[rowno-1][2]=cl2.getStringCellValue();			
			//System.out.println(testdata[rowno-1][2]);
			
			XSSFCell cl3=r.getCell(3);
			testdata[rowno-1][3]=cl3.getStringCellValue();	
			
			XSSFCell cl4=r.getCell(4);
			testdata[rowno-1][4]=cl4.getStringCellValue();	
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}	
	}
	
	
}


