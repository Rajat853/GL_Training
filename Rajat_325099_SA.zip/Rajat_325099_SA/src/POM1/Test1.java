package POM1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test1 {
	
	login_page lp;
	home_page hp;
	cart_page cp;
	WebDriver dr;
	
	@BeforeClass
	public void bc() {
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp=new login_page(dr);
		hp=new home_page(dr);
		cp=new cart_page(dr);
	
	}
	
  @Test
  public void f() {
	
	  String er="Sauce Labs Backpack";
	  lp.login("standard_user", "secret_sauce");
	  hp.add_to_cart(1);
	  hp.click_cart();
	  String ar=cp.verify();
	
	 SoftAssert sa=new SoftAssert();
	 sa.assertEquals(ar, er);	  
	 sa.assertAll();
	  
  }
}
