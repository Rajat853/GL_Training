package POM1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page {

	WebDriver dr;
	
	login_page(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	
	public void enter_uername(String uid) {	
	dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(uid);	
	}
	
	public void enter_password(String pwd) {
		dr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(pwd);
	}
	
	public void click_btn() {
		dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
	}
	
	public void login(String uid,String pwd) {
		enter_uername(uid);
		enter_password(pwd);
		click_btn();
	}
	
}
