package Assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		
		dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
		
		dr.findElement(By.id("FirstName")).sendKeys("Rajat");
		dr.findElement(By.id("LastName")).sendKeys("Kumar");
		dr.findElement(By.id("Email")).sendKeys("rajat.1410115@kiet.edu");
		dr.findElement(By.id("Password")).sendKeys("9876543233");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("9876543233");
		dr.findElement(By.id("register-button")).click();
		
		String ar="rajat.1410115@kiet.edu";
		String er= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		if(ar.equals(er))
			System.out.println("Pass");
		
		
	}

}
