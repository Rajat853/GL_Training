package S_Day6;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class excel_operations {


	
	 public String read_excel(int row,int n) {
     
		 String s="";
		try {
		File f=new File("KeyDataDriven1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
			XSSFRow r=sh.getRow(row);
			
			XSSFCell c=r.getCell(n);			
			 s= c.getStringCellValue();
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return s;
	}
}
