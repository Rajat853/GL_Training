package S_Day6;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String kw,loc,td;
		WebDriver dr=null;
		all_webelement_fns we=new all_webelement_fns(dr);
		excel_operations excel=new excel_operations();
		 for(int r=1;r<=4;r++) {
			 
			 kw=excel.read_excel(r,1);
			 loc=excel.read_excel(r,2);
			 td=excel.read_excel(r,3);
			 
			 switch(kw) {
			 
			 case "launchchrome":
			 we.launchChrome(td);
			 break;
			 
			 case "enter_txt":
			 we.enter_txt(loc,td);
			 break;
			 
			 case "click_btn":
			 we.click(loc);
			 break;
			 
			 }
		 }
		
		
	}

}
