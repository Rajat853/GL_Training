package S_Day6;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class pgm3 {
  
	@Test(dataProvider="security")
  public void f(String a,String b,String c) {
	  
		System.out.println(a+ " "+b+" "+c+" ");
	  
  }
  
	@DataProvider(name="security")
			public String[][] getdata(){
		
		String [][] data= {{"uid","pwd1","er1"},
				{"uid","pwd1","er1"}
				
		                  };
		return data;
	}
	
  
}
