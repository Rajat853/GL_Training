package S_Day6;

public class login_data {

	String uid,pwd,e_res,e_em1,e_em2,a_res,a_em1,a_em2,test;
	
	
}
