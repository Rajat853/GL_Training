package S_Day6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest3 {
  
  login_data loginobj,lobj;
  
	
	@Test
  public void f() {
		loginobj=new login_data();
		loginobj.uid="rajat.1510114@kiet.edu";
		loginobj.pwd="9536014722r";
		loginobj.e_res="SUCCESS";
		lobj=mainClass.login(loginobj);
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(lobj.e_res, loginobj.e_res);
		
		System.out.println("Actual Result : "+lobj.a_res);
		sa.assertAll();
  }
	
	
	@Test
	  public void f1() {
			loginobj=new login_data();
			loginobj.uid="rajat.1510114@kiet.edu";
			loginobj.pwd="953602r";
			loginobj.e_res="SUCCESS";
			loginobj.a_em1="Login was unsuccessful. Please correct the errors and try again.";
			loginobj.a_em2="The credentials provided are incorrect";
			lobj=mainClass.login(loginobj);
			
			SoftAssert sa=new SoftAssert();
			sa.assertEquals(lobj.a_res,loginobj.e_res);
			
			System.out.println("Actual Result : "+lobj.a_res   +
					           " , Actual Error Message1 : "+lobj.a_em1  +
					           " , Actual Error Message2 : "+lobj.a_em2);
			sa.assertAll();
			
	  }
}
