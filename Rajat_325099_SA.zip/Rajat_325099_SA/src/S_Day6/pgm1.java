package S_Day6;

import org.testng.annotations.Test;

public class pgm1 {

	@Test(priority=0)
  public void f() {
  System.out.println("In test f");
  }
	
	@Test(priority=1)
	  public void a() {
	  System.out.println("In test a ");
	  }
}
