package S_Day6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;


public class pgm {

	
	login_data login,logout;

	
	@BeforeClass
	public void BC() {
		login=new login_data();
		logout=new login_data();
	}
	
	
	@Test(dataProvider="security")
     public void login_test1(String u,String p,String exp_res) {
		
		System.out.println("Login : "+u+" "+p);
		login.uid=u;
		login.pwd=p;
		login.e_res=exp_res;
		
		logout=mainClass.login(login);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(logout.a_res, login.e_res);
		sa.assertAll();
		
	}
	
	@DataProvider(name="security")
			public String[][] method() {
		
		     String[][] data= {{"rajat.1510114@kiet.edu","9536014722r","SUCCESS"},
		                         {"rajat.1510114@kiet.edu","ffyjdfg","FAILURE"}
	                          };
		     return data;
	}
	
}
