package S_Day6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class mainClass {

	
	  public static login_data login(login_data ld) {

			System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
			WebDriver dr=new ChromeDriver();
		
				dr.get("http://demowebshop.tricentis.com/login");
				
			dr.findElement(By.id("Email")).sendKeys(ld.uid);
			dr.findElement(By.id("Password")).sendKeys(ld.pwd);
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			
			String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
			
			String ares="",aem1="",aem2="";
			
			if(s.equals("Log in")) {
			
				 if(aem1.equals(ld.e_em1) && aem2.equals(ld.e_em2))
						{
							ld.a_res="SUCCESS";
						}
				 
						else {
						
							ld.a_res="FAILURE";
						}
				 
			}
			
				 else {
					ld.a_res="SUCCESS";
					dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
				 }
			
			try {
				Thread.sleep(2000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			dr.close();
			return ld;
			}
			
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
