package Parallel;

import org.testng.annotations.Test;

public class parl1 {

	@Test
	public void t1() {
		System.out.println("Test1");
		
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Stop1");
	}
	
	
	@Test
	public void t2() {
		System.out.println("Test2");
		
		try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Stop2");
	}
}
