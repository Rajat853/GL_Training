package S_DAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {

	static int i=1;
	public static login_data read_excel() {
		
		login_data ld = new login_data();
		
		try {
			File f = new File("WebTesting.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			
			XSSFRow r=sh.getRow(i);
		    XSSFCell c=r.getCell(0);
		    ld.uid = c.getStringCellValue();
		    
		    XSSFCell c1=r.getCell(1);
		    ld.pass=c1.getStringCellValue();
		    
		    XSSFCell c2=r.getCell(2);
		    ld.er = c2.getStringCellValue();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		 return ld;
	}
	
	
	public static void web() {
		
		
		login_data l=read_excel();
		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		
		dr.findElement(By.id("Email")).sendKeys(l.uid);
		dr.findElement(By.id("Password")).sendKeys(l.pass);
		
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		
		String acr=l.uid;
		
		if(s.equals(acr))
			write(l);
		
	}
	
	public static void write(login_data ldd) {
		
		try {
			
			File f=new File("WebTesting.xlsx");
			FileInputStream fis= new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			XSSFRow r= sh.getRow(1);
			
			XSSFCell c=r.createCell(3);
		    c.setCellValue("Valid");
		    
		    XSSFCell c1=r.createCell(4);
		    c1.setCellValue("Pass");
			
		    FileOutputStream fos = new FileOutputStream(f);
		    wb.write(fos);
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		web();
	}

	/*
	  Explicit code
	  
	WebDriverWait wt = new WebDriverWait(dr,10);
	wt.until(ExpectedConditions.elementToBeClickable(By.xpath("dhsu")));
	  wt.until(ExpectedConditions.titileContains("Facebook"));

	dr.findElement(By.xpath()).click(); 
	 */

	/*
	 Implicit Code
	 dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 
	  */
	 
	
}
