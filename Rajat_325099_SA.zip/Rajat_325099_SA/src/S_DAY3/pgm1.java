package S_DAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v77.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		
		dr.findElement(By.className("buttonClass")).click();
		
		String er=dr.findElement(By.xpath("//*[@id=\"post-4690\"]/div[1]/h1")).getText();

		String ar="Button success";
		
		if(er.equals(ar))
			System.out.println("Pass");
		else
			System.out.println("Fail");
		
	}

}
