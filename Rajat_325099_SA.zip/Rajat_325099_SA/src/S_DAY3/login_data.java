package S_DAY3;

public class login_data {

	String uid;
	String pass;
	String er;
	String ar;
	String tr;
	
}
