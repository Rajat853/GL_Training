package S_DAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "chromedriver_v77.exe");
		WebDriver dr= new ChromeDriver();
		
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		
//		boolean b=dr.findElement(By.xpath("//*[@id=\\\"et-boc\\\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).isSelected();
//		
//		if(b==false)
//			dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[8]/div/div/div/form/input[1]")).click();
//	
//	
		
		dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/ul/li[1]/a")).click();
		
		String er=dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[3]/div/div[1]/div[10]/div/div[1]/div")).getText();
		String ar="tab 1 content";
		
		if(er.equals(ar))
			System.out.println("Pass");
	
		else
			System.out.println("Fail");
	}

}
