package HybridFramework;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {

	public static String fileName="HFW.xlsx";
	public static String key_sheet="Keyword";
	public static String Sel_sheet="TC_Selection_SH";
	public static String log_sheet="LoginData";
	public static XSSFSheet kw,sel,log;
	
	public static ArrayList<LoginData> al;
	
	public static XSSFSheet set_sheet(String sheetName) {
		
		XSSFSheet sh=null;
		
		try {
		File f=new File(fileName);
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		 sh= wb.getSheet(sheetName);
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return sh;
		
	}
	
	
	
	public static Keyword read_Keyword(int i) {
		kw=set_sheet(key_sheet);
		
		Keyword k=new Keyword();
		
		XSSFRow r=kw.getRow(i);
		
		XSSFCell c2=r.getCell(0);
		k.tcid=c2.getStringCellValue();
		
		XSSFCell c=r.getCell(3);
		k.keywd=c.getStringCellValue();
		
		
        XSSFCell c1=r.getCell(4);
		
		k.xp=c1.getStringCellValue();
		
		return k;
	}
	
	
	public static Selection read_TC_Selection_Sh(int i) {
		
		sel=set_sheet(Sel_sheet);
		Selection s =new Selection();
		
		
		XSSFRow r=sel.getRow(i);
		
		s.tid=r.getCell(0).getStringCellValue();
		
		
		s.flag=r.getCell(1).getStringCellValue();
		
		XSSFCell c=r.getCell(2);
		s.nos=(int)c.getNumericCellValue();
		
		
		s.sheet=r.getCell(3).getStringCellValue();
	
		
		return s;
		
	}
	
	public static ArrayList<LoginData> read_LoginData(){
		
		log=set_sheet(log_sheet);
		System.out.println();
		
		al= new ArrayList<LoginData>();
		
		for(int i=1;i<3;i++) {
		LoginData ld =new LoginData();
		
       XSSFRow r=log.getRow(i);
		
		XSSFCell c=r.getCell(0);
		ld.uid=c.getStringCellValue();
		

		XSSFCell c1=r.getCell(1);
		ld.pwd=c1.getStringCellValue();
		
		al.add(ld);
		}
		
		return al;
	}
	

	
	
	
}
