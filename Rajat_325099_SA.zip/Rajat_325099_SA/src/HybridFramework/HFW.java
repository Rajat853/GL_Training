package HybridFramework;

import java.util.ArrayList;

public class HFW  extends keywordMethod{

	static Selection s;
	static Keyword k;
	static ArrayList<LoginData> alld;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int i,j,l;
		
		for(i=1;i<=3;i++) {
			s=new Selection();
			boolean val=false;
			
			s=read_TC_Selection_Sh(i);
			
			
			if(s.flag.equals("Y")) {
				
				for(j=1;j<7;j++) {
					k=new Keyword();
					k=read_Keyword(j);
					
					if(s.tid.equals(k.tcid))
					{
						val=true;
						break;
					}
					else
						continue;
				}
	
				
				if(val) {
					alld=new ArrayList<LoginData>();
					alld=read_LoginData();
					
					
					for(LoginData ld:alld) {
						String s1="";
						
						
					for(l=j;l<7;l++){
					
						k=new Keyword();
						k=read_Keyword(l);
						if(l==3)
						s1=ld.uid;
						else
							s1=ld.pwd;
						
						switch(k.keywd) {
						
						case "launchchrome":
							launchchrome(k.xp);
							break;
							
						case "click_btn":
							click_btn(k.xp);
							break;
							
						
						case "enter_txt":
							enter_txt(k.xp,s1);
							break;
							
						case "Verify":
						   Verify(k.xp);
						break;
							
						}//switch
						
					}//end l loop
					
					}//end for-each loop
					
				}//if value end
					
				
			}  
			
			
		}//outer for loop  
		
		
		
	} //main		
	}
