package HybridFramework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

public class keywordMethod extends excel_read{

	static WebDriver dr;
	
	public static void launchchrome(String url) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_78.exe");
		dr=new ChromeDriver();
		dr.get(url);	
	}
	
	public static void click_btn(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	
	public static void enter_txt(String xp,String data) {
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	
	public static void Verify(String xp) {
		
		String s=dr.findElement(By.xpath(xp)).getText();
		
		SoftAssert sa=new SoftAssert();
		sa.assertEquals("rajat.1510114@kiet.edu",s);
		
		System.out.println("Valid ");
		
		sa.assertAll();
	
	}
	
}
