package HybridFramework;

public class Keyword {

	String tcid;
	String keywd;
	String xp;
	String data;
	
}
