package HybridFramework;

public class LoginData {

	String uid;
	String pwd;
	
}
