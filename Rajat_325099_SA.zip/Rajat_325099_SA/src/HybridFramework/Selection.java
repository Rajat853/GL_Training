package HybridFramework;

public class Selection {

	String tid;
	String flag;
	int nos;
	String sheet;	
}
