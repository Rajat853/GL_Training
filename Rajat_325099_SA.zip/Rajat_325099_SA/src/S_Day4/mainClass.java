package S_Day4;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class mainClass {

	
	  public static void login() {

			System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
			WebDriver dr=new ChromeDriver();
			
			
			ArrayList<login_data> al=new ArrayList<login_data>();
			al=readwrite.read_excel();
			
			
			for(login_data l:al) {
				
				dr.get("http://demowebshop.tricentis.com/login");
				
			dr.findElement(By.id("Email")).sendKeys(l.uid);
			dr.findElement(By.id("Password")).sendKeys(l.pwd);
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
			
			String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
			
			String ares="",aem1="",aem2="";
			
			if(s.equals("Log in")) {
				 ares="FAILURE";
				 aem1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
				 aem2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
				 if(aem1.equals(l.e_em1) && aem2.equals(l.e_em2))
						{
							readwrite.add(l,ares,aem1,aem2,"PASS");
						}
				 
						else {
						
							readwrite.add(l,ares,aem1,aem2,"FAIL");
						}
				 
			}
			
				 else {
					 ares="SUCCESS";
					 readwrite.add(l,ares,aem1,aem2,"PASS");
					 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
				 }
			
			try {
				Thread.sleep(3000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}

			dr.close();
			}
			
			
	  }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		login();
		readwrite.write();
		
	}

}
