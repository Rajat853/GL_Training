package S_Day4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readwrite {

	static ArrayList<login_data> a1=new ArrayList<login_data>();
	static int c=0;
	
	
	public static ArrayList<login_data> read_excel() {
			
		try {
			
			File f = new File("TestCase1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
			for(int i=1;i<=2;i++) {
				login_data ld=new login_data();
				
				XSSFRow r=sh.getRow(i);
				
				XSSFCell c=r.getCell(0);
				ld.uid=c.getStringCellValue();
				
				XSSFCell c1=r.getCell(1);
				ld.pwd=c1.getStringCellValue();
				
				XSSFCell c2=r.getCell(2);
				ld.e_res=c2.getStringCellValue();
				
				if(ld.e_res.equals("SUCCESS"))
				{
					ld.e_em1="";
					ld.e_em2="";
				}
				else {
				XSSFCell c3=r.getCell(3);
				ld.e_em1=c3.getStringCellValue();
				
				XSSFCell c4=r.getCell(4);
				ld.e_em2=c4.getStringCellValue();
				}
				a1.add(ld);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return a1;
		
	}
	
	public static void add(login_data l,String s1,String s2,String s3,String s4) {
	 l.a_res=s1;
	 l.a_em1=s2;
	 l.a_em2=s3;
	 l.test=s4;
		
	 a1.set(c++,l);
	}
	
	
	public static void write() {
		
		try {
		File f = new File("TestCase1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		  int j=0;
         for(int i=1;i<=2;i++) {
        	 login_data l =new login_data();
        	 l=a1.get(j);
        	 XSSFRow r=sh.getRow(i);
        	 
        	 XSSFCell c5=r.createCell(5);
        	 c5.setCellValue(l.a_res);
        	 
        	 XSSFCell c6=r.createCell(6);
        	 c6.setCellValue(l.a_em1);
        	 
        	 XSSFCell c7=r.createCell(7);
        	 c7.setCellValue(l.a_em2);
        	 
        	 XSSFCell c8=r.createCell(8);
        	 c8.setCellValue(l.test);
        	 
        	 FileOutputStream fos = new FileOutputStream(f);
        	 wb.write(fos);
         j++;
         }
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}
	
}
