package S_Day4;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v77.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("https://demo.guru99.com/test/delete_customer.php");
		
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("123");
		
		dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
	
	    try {
	    	Thread.sleep(3000);
	    }
	    catch(Exception e) {
	    	e.printStackTrace();
	    }
	    
	    Alert e = dr.switchTo().alert();
	    String s=e.getText();
	    System.out.println(s);
	    e.accept();
	    
	    
	    try {
	    	Thread.sleep(3000);
	    }
	    catch(Exception e1) {
	    	e1.printStackTrace();
	    }
	    
	    Alert a = dr.switchTo().alert();
	    String s1=a.getText();
	    System.out.println(s1);
	    a.accept();
	
	}

}
