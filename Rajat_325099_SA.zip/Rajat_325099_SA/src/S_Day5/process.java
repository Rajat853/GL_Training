package S_Day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class process {
	

	ArrayList<details> a1;
	
	public ArrayList<details> get_data(){

		a1=new ArrayList<details>();
		try {
			
			
			File f = new File("TestCase1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			
		 for(int i=1;i<=4;i++) {
			 details d=new details();
			 
			 XSSFRow r=sh.getRow(i);
			 
			 XSSFCell c=r.getCell(0);
			 d.uid=c.getStringCellValue();
			 
			 XSSFCell c1=r.getCell(1);
			 d.pwd=c1.getStringCellValue();
			 
			 XSSFCell c2=r.getCell(2);
			 d.e_res=c2.getStringCellValue();
			 
			 if(d.e_res.equals("SUCCESS"))
				{
					d.e_em1="";
					d.e_em2="";
				}
			 
			 
			 else {
			
				 XSSFCell c3=r.getCell(3);
				 d.e_em1=c3.getStringCellValue();
				 
				 XSSFCell c4=r.getCell(4);
				 d.e_em2=c4.getStringCellValue();
				 

			 }
			 a1.add(d);
			 
		 }
		
	}

      catch(Exception e) {
    	  e.printStackTrace();
      }
		return a1;
}
	
     public void write(ArrayList<details> a) {
		
		try {
		File f = new File("TestCase1.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		
		int j=0;
         for(int i=1;i<=4;i++) {
        	 
        	 details l =new details();
        	 l=a.get(j);
        	 
        	 XSSFRow r=sh.getRow(i);
        	 
        	 XSSFCell c5=r.createCell(5);
        	 c5.setCellValue(l.a_res);
        	 
        	 XSSFCell c6=r.createCell(6);
        	 c6.setCellValue(l.a_em1);
        	 
        	 XSSFCell c7=r.createCell(7);
        	 c7.setCellValue(l.a_em2);
        	 
        	 XSSFCell c8=r.createCell(8);
        	 c8.setCellValue(l.test);
        	 
        	 FileOutputStream fos = new FileOutputStream(f);
        	 wb.write(fos);
         j++;
         }
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}
	
	
	
	
	
}
