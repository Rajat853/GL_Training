package S_Day5;

public class details {

	String uid,pwd,e_res,e_em1,e_em2,a_res,a_em1,a_em2,test;
}
