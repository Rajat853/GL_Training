package S_Day5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	
	  @BeforeClass
	  public void BC() {
		System.out.println("I came to the cricket stadium");  
	  }
	  
	  
	  @AfterClass
	  public void AC() {
		System.out.println("Now I am back home");  
	  }
	  
	
	@BeforeMethod
	public void BM() {
		System.out.println("Hello");
	}
	
	@Test
	public void a() {
		System.out.println("I met Mr. Dhoni");
	}
	

	@AfterMethod
	public void AM() {
		System.out.println("Bye");
	}
	
	@Test
	public void b() {
		System.out.println("I had my lunch with Mr. Virat Kohli");
	}
	
	
	@Test
	public void c() {
		System.out.println("I took a picture with Mr. Rohit Sharma");
	}
  
}
