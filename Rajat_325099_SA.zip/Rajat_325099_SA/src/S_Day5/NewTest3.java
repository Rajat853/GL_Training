package S_Day5;

import org.testng.annotations.Test;

public class NewTest3 {
  
  login_data loginobj,lobj;
  
	
	@Test
  public void f() {
		loginobj=new login_data();
		loginobj.uid="rajat.1510114@kiet.edu";
		loginobj.pwd="9536014722r";
		loginobj.e_res="SUCCESS";
		lobj=mainClass.login(loginobj);
		
		System.out.println(lobj.a_res);
		
  }
	
	
	@Test
	  public void f1() {
			loginobj=new login_data();
			loginobj.uid="rajat.1510114@kiet.edu";
			loginobj.pwd="953602r";
			loginobj.e_res="FAILURE";
			loginobj.a_em1="Login was unsuccessful. Please correct the errors and try again.";
			loginobj.a_em2="The credentials provided are incorrect";
			lobj=mainClass.login(loginobj);
			
			System.out.println("Actual Result : "+lobj.a_res   +
					           "Actual Error Message1 : "+lobj.a_em1  +
					           "Actual Error Message2 : "+lobj.a_em2);
			
	  }
}
