package S_Day5;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	System.out.println("in test f");  
  }
  
  @Test
  public void t2() {
		System.out.println("in test t2");  
	  }
  
}
