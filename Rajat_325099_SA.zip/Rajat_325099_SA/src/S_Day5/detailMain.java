package S_Day5;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class detailMain {

  
	public static details login(details ld) {
		
		System.setProperty("webdriver.chrome.driver","chromedriver_78.exe");
		WebDriver dr=new ChromeDriver();
	 
		dr.get("http://demowebshop.tricentis.com/login");
			
			dr.findElement(By.id("Email")).sendKeys(ld.uid);
			dr.findElement(By.id("Password")).sendKeys(ld.pwd);
			dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

			String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).getText();
	
			String aem1="",aem2="";
			
			if(s.equals("Log in")) {
				 ld.a_res="FAILURE";
				 aem1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
				 aem2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
				 if(aem1.equals(ld.e_em1) && aem2.equals(ld.e_em2))
						{
							ld.test="PASS";
							ld.a_em1=aem1;
							ld.a_em2=aem2;
						}
				 
						else {
						
							ld.test="FAIL";
							ld.a_em1=aem1;
							ld.a_em2=aem2;

						}
				 
			}
			
				 else {
					 ld.a_res="SUCCESS";
					 ld.test="PASS";
					 ld.a_em1=aem1;
   					 ld.a_em2=aem2;
					 dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
				 }
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			dr.close();
	      return ld;		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<details> a2=new ArrayList<details>();
		process p= new process();
		a2=p.get_data();
		int c=0;
		for(details d:a2) {
			details ud=login(d);
			a2.set(c,ud);
			c++;
		}
		
		p.write(a2);
	}

}
