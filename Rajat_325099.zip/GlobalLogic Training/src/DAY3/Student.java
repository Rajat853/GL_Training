package DAY3;

public class Student {

	public int rollno;
	public String name;
	public int m1;
	public int m2;
	public float avg;
	
	
	public void average() {
		this.avg=(this.m1+this.m2);
	}
	
}
