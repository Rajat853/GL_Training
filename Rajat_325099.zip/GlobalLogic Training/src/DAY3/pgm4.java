package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int mat[][]= {{3,5,12,},{9,5,2},{12,54,1}};
		
		for(int i=0;i<3;i++) {
			int max=0;
			for(int j=0;j<3;j++) {
				if(mat[i][j]>max)
					max=mat[i][j];
			}
			System.out.println("Greatest number in row "+i+" = "+max);
			
		}
		
		
	}

}
