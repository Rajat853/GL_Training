package DAY3;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  
		int arr[]= {1,2,3,4,5,6};
	    int sum=0;
	    float avg;
		for(int i=0;i<6;i++) {
			sum+=arr[i];
		}
		avg=sum/6;
		
		System.out.println(avg);
		
	}

}
