package DAY1;
import java.util.*;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the first subject number");
		int sub1=sc.nextInt();
		System.out.println("Enter the second subject number");
		int sub2=sc.nextInt();
		System.out.println("Enter the third subject number");
		int sub3=sc.nextInt();
		int stu_cls;
		
		stu_cls=(sub1+sub2+sub3)/3;
		System.out.println("Average number="+stu_cls);
		if(stu_cls>=60)
		System.out.println("First class");
		else if(stu_cls>=50 && stu_cls<60)
		System.out.println("Second class");
		else if(stu_cls>=35 && stu_cls<=50)
		System.out.println("Pass class");
		else
		System.out.println("Fail");
	
		
	}
	
}
