package DAY1;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=5;
		int b=8;
		
		if(a<b)
			System.out.println("a is less than b");
		else
			System.out.println("a is equal to b");
		
	}

}
