package DAY1;

public class pgm1 {

	public void prime() {
	int sum=0,count=0;
	int i=2;
		
		while(count<10) {
	
			boolean val=true;
			
			for(int j=2;j<=i/2;j++) {
				
				if(i%j==0) {
					val=false;
					break;
				}
			
			}
			if(val==true) {
				sum+=i;
				count++;
				System.out.println(i);
			}
			i++;
		}
		
		System.out.println("Sum = "+sum);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm1 p=new pgm1();
		p.prime();
		

		
		
		
	}

}
