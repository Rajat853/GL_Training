package DAY1;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=2,b=7,c=5;
		
		if(a>b && a>c)
			System.out.println(a+ "is the largest among three");
		else if(b>c)
		System.out.println(b+ " is the largest among three");
		else
			System.out.println(c+ " is the largest among three");
		


		
		if(a<b && a<c)
			System.out.println(a+ " is the smallest among three");
		else if(b<c)
			System.out.println(b+ " is the smallest among three");
		else
			System.out.println(c+ " is the smallest among three");
	}
	
	

}
