package DAY1;
import java.util.*;

public class pgm2 {

	public void palindrome(int num) {
		int num2=0,d=0;
		int temp=num;
		while(temp>0){
			d=temp%10;
			num2=num2*10+d;
			temp=temp/10;
		}
		
		if(num2==num)
			System.out.println(num +" is Palindrome");
		else
			System.out.println(num +" is not Palindrome");
	}
	
	public static void main(String arg[]) {
		pgm2 p2=new pgm2();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		p2.palindrome(n);
		
		
	}
	
}
