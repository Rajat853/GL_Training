package DAY2;

public class pgm11 {

	
	public static boolean isPrime(int x) {
	
		boolean val=true;
		for(int i=2;i<x/2;i++) {
			if(x%i==0) {
				val=false;
				break;
			}
			
		}
		return val;
	
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	int n=1,i=2;
	while(n<=10) {
		if(isPrime(i)) {
			System.out.println(i+" is prime number");
			n++;
		}
		 i++;
		
	}

	}

}
