package DAY2;
import java.util.*;
public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
	  String str=sc.next();
	  int len=str.length()-1;
	  
	  while(len>=0) {
		  int temp=str.charAt(len);
		  len--;
		  switch(temp) {
		  case '0':
			  System.out.println("Zero");
			  break;
		  
		  case '1':
			  System.out.println("One");
			  break;
		
		  case '2':
			  System.out.println("Two");
			  break;
		
		  case '3':
			  System.out.println("Three");
			  break;
		
		  case '4':
			  System.out.println("Four");
			  break;
		
		  case '5':
			  System.out.println("Five");
			  break;
		
		  case '6':
			  System.out.println("Six");
			  break;
		
		  case '7':
			  System.out.println("Seven");
			  break;
		  case '8':
			  System.out.println("Eight");
			  break;
		
		  case '9':
			  System.out.println("Nine");
			  break;
		
		  }
		  
	  }
	  
	  
	
	}

	
	
}
