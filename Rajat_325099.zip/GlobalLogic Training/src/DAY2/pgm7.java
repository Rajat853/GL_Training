package DAY2;

import java.util.*;
public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n= new Scanner(System.in).nextInt();
		int sum=0;
		
		while(n>0) {
			int d=n%10;
			if(d>5)
				sum+=d;
			
			n/=10;
		}
System.out.print(sum);
		
	}

}
