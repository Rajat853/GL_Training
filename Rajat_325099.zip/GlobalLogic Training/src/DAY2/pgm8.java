package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int sum=0,i=15;
		while(i<=75){
			if(i%7==0)
				sum+=i;
			i++;
		}
		
		System.out.println(sum);
	}

}
